

#ifndef SORTOWNIA_INTROSORT_H
#define SORTOWNIA_INTROSORT_H
#include "Quicksort.h"

//void Insertionsort(int *tab, int left, int right);
void HeapMaximum(int * tab, int heapSize, int q);
void Heapsort(int *tab, int right);
//void Introsort(int * tab, int left, int right, int maxdepth);

#endif //SORTOWNIA_INTROSORT_H
