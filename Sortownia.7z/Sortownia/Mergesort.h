#ifndef SORTOWNIA_MERGESORT_H
#define SORTOWNIA_MERGESORT_H

void Mergesort(int *tab, int *q, int left, int right);
void Merge(int *tab, int *q, int left, int mid, int right);

#endif //SORTOWNIA_MERGESORT_H
