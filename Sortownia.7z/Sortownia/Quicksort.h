

#ifndef SORTOWNIA_QUICKSORT_H
#define SORTOWNIA_QUICKSORT_H


void Quicksort(int *tab, int left, int right);
int Partition(int *tab, int left, int right);



#endif //SORTOWNIA_QUICKSORT_H
